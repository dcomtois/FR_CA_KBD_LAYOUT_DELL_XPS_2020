Start setup to install the Canadian French keyboard layout with 
the addition of AltGr-z for « and AltGr-x for ».

Démarrer setup pour installer le layout Canadien Français avec
la fonctionnalité additionnelle AltGr-z pour « et AltGr-x pour ».

D. Comtois, 2020